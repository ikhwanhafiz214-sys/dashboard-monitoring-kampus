const STORAGE_KEY = "dashboardMonitoringKampus_v1";

const defaultDevices = [
    {
        id: "DEV-001",
        name: "Sensor Ruang Server",
        location: "Ruang Server",
        temperature: 24.8,
        humidity: 55,
        limit: 28,
        connection: "online",
        history: [24.2, 24.5, 24.3, 24.7, 24.8]
    },
    {
        id: "DEV-002",
        name: "Sensor Lab Komputer 1",
        location: "Lab Komputer 1",
        temperature: 26.4,
        humidity: 60,
        limit: 30,
        connection: "online",
        history: [25.9, 26.1, 26.2, 26.0, 26.4]
    },
    {
        id: "DEV-003",
        name: "Sensor Lab Elektronika",
        location: "Lab Elektronika",
        temperature: 27.8,
        humidity: 63,
        limit: 28,
        connection: "online",
        history: [26.8, 27.0, 27.4, 27.6, 27.8]
    },
    {
        id: "DEV-004",
        name: "Sensor Ruang Kelas 4A",
        location: "Gedung Teknik Komputer",
        temperature: 25.7,
        humidity: 58,
        limit: 30,
        connection: "online",
        history: [25.4, 25.6, 25.5, 25.9, 25.7]
    },
    {
        id: "DEV-005",
        name: "Sensor Laboratorium Jaringan",
        location: "Lab Jaringan",
        temperature: 31.2,
        humidity: 68,
        limit: 30,
        connection: "offline",
        history: [29.1, 29.8, 30.2, 30.8, 31.2]
    }
];

let devices = loadData();
let simulationTimer = null;
let chart = null;

const $ = (id) => document.getElementById(id);

function clone(data) {
    return JSON.parse(JSON.stringify(data));
}

function loadData() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length) return parsed;
        }
    } catch (error) {
        console.warn("LocalStorage tidak dapat dibaca:", error);
    }
    return clone(defaultDevices);
}

function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(devices));
    } catch (error) {
        showToast("Data tampil, tetapi localStorage tidak tersedia.");
    }
}

function getCondition(device) {
    if (device.connection === "offline") return "offline";
    if (Number(device.temperature) > Number(device.limit)) return "warning";
    return "normal";
}

function conditionText(condition) {
    return {
        normal: "Normal",
        warning: "Peringatan",
        offline: "Offline"
    }[condition];
}

function formatNumber(value) {
    return Number(value).toFixed(1);
}

function renderSummary() {
    const normal = devices.filter(d => getCondition(d) === "normal").length;
    const warning = devices.filter(d => getCondition(d) === "warning").length;
    const offline = devices.filter(d => getCondition(d) === "offline").length;

    $("totalDevices").textContent = devices.length;
    $("normalDevices").textContent = normal;
    $("warningDevices").textContent = warning;
    $("offlineDevices").textContent = offline;
}

function renderDevices() {
    const search = $("searchInput").value.trim().toLowerCase();
    const filter = $("statusFilter").value;

    const filtered = devices.filter(device => {
        const condition = getCondition(device);
        const matchSearch =
            device.name.toLowerCase().includes(search) ||
            device.location.toLowerCase().includes(search);
        const matchFilter = filter === "all" || condition === filter;
        return matchSearch && matchFilter;
    });

    $("deviceGrid").innerHTML = filtered.map(device => {
        const condition = getCondition(device);
        const connectionText = device.connection === "online" ? "Online" : "Offline";

        return `
            <article class="device-card">
                <div class="device-head">
                    <div>
                        <div class="device-name">${escapeHtml(device.name)}</div>
                        <div class="device-location">📍 ${escapeHtml(device.location)}</div>
                    </div>
                    <span class="badge ${condition}">${conditionText(condition)}</span>
                </div>

                <div class="device-values">
                    <div class="value-box">
                        <span>Suhu</span>
                        <strong>${formatNumber(device.temperature)} °C</strong>
                    </div>
                    <div class="value-box">
                        <span>Kelembapan</span>
                        <strong>${formatNumber(device.humidity)} %</strong>
                    </div>
                    <div class="value-box">
                        <span>Batas Suhu</span>
                        <strong>${formatNumber(device.limit)} °C</strong>
                    </div>
                    <div class="value-box">
                        <span>Koneksi</span>
                        <strong>${connectionText}</strong>
                    </div>
                </div>

                <div class="device-footer">
                    <span class="limit">ID: ${escapeHtml(device.id)}</span>
                    <div class="card-actions">
                        <button class="small-btn edit" onclick="editDevice('${device.id}')">Edit</button>
                        <button class="small-btn delete" onclick="deleteDevice('${device.id}')">Hapus</button>
                    </div>
                </div>
            </article>
        `;
    }).join("");

    $("emptyState").classList.toggle("hidden", filtered.length !== 0);
}

function renderChartOptions() {
    const current = $("chartDevice").value;
    $("chartDevice").innerHTML = devices.map(d =>
        `<option value="${escapeHtml(d.id)}">${escapeHtml(d.name)}</option>`
    ).join("");

    if (devices.some(d => d.id === current)) {
        $("chartDevice").value = current;
    }
    updateChart();
}

function drawChart() {
    const canvas = $("temperatureChart");
    const ctx = canvas.getContext("2d");
    const device = devices.find(d => d.id === $("chartDevice").value);

    if (!device || !device.history || device.history.length === 0) {
        $("chartEmpty").classList.remove("hidden");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        return;
    }

    $("chartEmpty").classList.add("hidden");

    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 390;
    const ratio = window.devicePixelRatio || 1;
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);

    const values = device.history;
    const pad = { left: 48, right: 20, top: 25, bottom: 42 };
    const plotW = width - pad.left - pad.right;
    const plotH = height - pad.top - pad.bottom;

    const min = Math.floor(Math.min(...values, device.limit - 2) - 1);
    const max = Math.ceil(Math.max(...values, device.limit + 2) + 1);

    ctx.clearRect(0, 0, width, height);
    ctx.font = "12px Segoe UI, Arial";
    ctx.fillStyle = "#6b7788";
    ctx.strokeStyle = "#e8edf3";
    ctx.lineWidth = 1;

    for (let i = 0; i <= 5; i++) {
        const y = pad.top + (plotH / 5) * i;
        const value = max - ((max - min) / 5) * i;

        ctx.beginPath();
        ctx.moveTo(pad.left, y);
        ctx.lineTo(width - pad.right, y);
        ctx.stroke();

        ctx.fillText(value.toFixed(0) + "°", 8, y + 4);
    }

    const limitY = pad.top + ((max - device.limit) / (max - min)) * plotH;
    ctx.setLineDash([6, 5]);
    ctx.strokeStyle = "#c77900";
    ctx.beginPath();
    ctx.moveTo(pad.left, limitY);
    ctx.lineTo(width - pad.right, limitY);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#9a5d00";
    ctx.fillText("Batas " + formatNumber(device.limit) + "°C", width - 100, limitY - 7);

    const points = values.map((value, index) => {
        const x = pad.left + (values.length === 1 ? plotW / 2 : (index / (values.length - 1)) * plotW);
        const y = pad.top + ((max - value) / (max - min)) * plotH;
        return { x, y, value };
    });

    ctx.strokeStyle = "#3157d5";
    ctx.lineWidth = 3;
    ctx.beginPath();
    points.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.stroke();

    points.forEach((p, i) => {
        ctx.beginPath();
        ctx.fillStyle = "#3157d5";
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fill();

        if (i === points.length - 1) {
            ctx.fillStyle = "#182230";
            ctx.font = "bold 12px Segoe UI, Arial";
            ctx.fillText(formatNumber(p.value) + "°C", p.x - 18, p.y - 12);
        }
    });

    ctx.fillStyle = "#6b7788";
    ctx.font = "11px Segoe UI, Arial";
    points.forEach((p, i) => {
        if (i === 0 || i === points.length - 1 || i % Math.ceil(points.length / 6) === 0) {
            ctx.fillText("T-" + (points.length - i - 1), p.x - 12, height - 17);
        }
    });
}

function updateChart() {
    drawChart();
}

function openModal(device = null) {
    $("deviceModal").classList.remove("hidden");

    if (device) {
        $("modalTitle").textContent = "Edit Perangkat";
        $("deviceId").value = device.id;
        $("deviceName").value = device.name;
        $("deviceLocation").value = device.location;
        $("deviceTemp").value = device.temperature;
        $("deviceHumidity").value = device.humidity;
        $("deviceLimit").value = device.limit;
        $("deviceConnection").value = device.connection;
    } else {
        $("modalTitle").textContent = "Tambah Perangkat";
        $("deviceForm").reset();
        $("deviceId").value = "";
        $("deviceTemp").value = 25;
        $("deviceHumidity").value = 55;
        $("deviceLimit").value = 30;
        $("deviceConnection").value = "online";
    }

    setTimeout(() => $("deviceName").focus(), 50);
}

function closeModal() {
    $("deviceModal").classList.add("hidden");
}

function saveDevice(event) {
    event.preventDefault();

    const id = $("deviceId").value || createId();
    const existing = devices.find(d => d.id === id);

    const data = {
        id,
        name: $("deviceName").value.trim(),
        location: $("deviceLocation").value.trim(),
        temperature: Number($("deviceTemp").value),
        humidity: Number($("deviceHumidity").value),
        limit: Number($("deviceLimit").value),
        connection: $("deviceConnection").value,
        history: existing?.history?.length ? existing.history : [Number($("deviceTemp").value)]
    };

    if (!data.name || !data.location) {
        showToast("Nama dan lokasi wajib diisi.");
        return;
    }

    if (existing) {
        devices = devices.map(d => d.id === id ? data : d);
        showToast("Perangkat berhasil diperbarui.");
    } else {
        devices.push(data);
        showToast("Perangkat berhasil ditambahkan.");
    }

    saveData();
    renderAll();
    closeModal();
}

function editDevice(id) {
    const device = devices.find(d => d.id === id);
    if (device) openModal(device);
}

function deleteDevice(id) {
    const device = devices.find(d => d.id === id);
    if (!device) return;

    if (!confirm(`Hapus perangkat "${device.name}"?`)) return;

    devices = devices.filter(d => d.id !== id);
    saveData();
    renderAll();
    showToast("Perangkat berhasil dihapus.");
}

function createId() {
    let number = 1;
    while (devices.some(d => d.id === `DEV-${String(number).padStart(3, "0")}`)) number++;
    return `DEV-${String(number).padStart(3, "0")}`;
}

function startSimulation() {
    if (simulationTimer) return;

    simulationTimer = setInterval(() => {
        devices = devices.map(device => {
            if (device.connection === "offline") {
                if (Math.random() < 0.15) device.connection = "online";
            } else {
                if (Math.random() < 0.04) device.connection = "offline";
            }

            if (device.connection === "online") {
                const change = (Math.random() - 0.48) * 1.2;
                device.temperature = Math.max(-50, Math.min(100, device.temperature + change));

                const humidityChange = (Math.random() - 0.5) * 3;
                device.humidity = Math.max(0, Math.min(100, device.humidity + humidityChange));
            }

            if (!Array.isArray(device.history)) device.history = [];
            device.history.push(Number(device.temperature.toFixed(1)));
            if (device.history.length > 20) device.history.shift();

            return device;
        });

        saveData();
        renderAll();
    }, 3000);

    $("startSimulation").disabled = true;
    $("stopSimulation").disabled = false;
    showToast("Simulasi dimulai. Data berubah setiap 3 detik.");
}

function stopSimulation() {
    if (!simulationTimer) return;

    clearInterval(simulationTimer);
    simulationTimer = null;
    $("startSimulation").disabled = false;
    $("stopSimulation").disabled = true;
    showToast("Simulasi dihentikan.");
}

function exportJSON() {
    const payload = {
        project: "Dashboard Monitoring Ruangan Kampus",
        exportedAt: new Date().toISOString(),
        devices: devices
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "data-monitoring-kampus.json";
    a.click();
    URL.revokeObjectURL(url);
    showToast("File JSON berhasil diekspor.");
}

function importJSON(file) {
    if (!file) return;

    const reader = new FileReader();

    reader.onload = event => {
        try {
            const parsed = JSON.parse(event.target.result);
            const imported = Array.isArray(parsed) ? parsed : parsed.devices;

            if (!Array.isArray(imported)) throw new Error("Format perangkat tidak ditemukan.");

            const valid = imported.filter(isValidDevice).map(normalizeDevice);

            if (valid.length === 0) {
                throw new Error("Tidak ada data perangkat yang valid.");
            }

            devices = valid;
            saveData();
            renderAll();
            showToast(`${valid.length} perangkat berhasil diimpor.`);
        } catch (error) {
            alert("Gagal mengimpor JSON. Pastikan file mengikuti format project.");
        }

        $("fileInput").value = "";
    };

    reader.readAsText(file);
}

function isValidDevice(d) {
    return d &&
        typeof d.name === "string" &&
        typeof d.location === "string" &&
        Number.isFinite(Number(d.temperature)) &&
        Number.isFinite(Number(d.humidity)) &&
        Number.isFinite(Number(d.limit)) &&
        ["online", "offline"].includes(d.connection);
}

function normalizeDevice(d, index) {
    return {
        id: d.id || `DEV-${String(index + 1).padStart(3, "0")}`,
        name: d.name,
        location: d.location,
        temperature: Number(d.temperature),
        humidity: Number(d.humidity),
        limit: Number(d.limit),
        connection: d.connection,
        history: Array.isArray(d.history) && d.history.length
            ? d.history.map(Number).filter(Number.isFinite).slice(-20)
            : [Number(d.temperature)]
    };
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

let toastTimer;
function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function renderAll() {
    renderSummary();
    renderDevices();
    renderChartOptions();
}

$("addDeviceBtn").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);
$("deviceForm").addEventListener("submit", saveDevice);
$("searchInput").addEventListener("input", renderDevices);
$("statusFilter").addEventListener("change", renderDevices);
$("chartDevice").addEventListener("change", updateChart);
$("startSimulation").addEventListener("click", startSimulation);
$("stopSimulation").addEventListener("click", stopSimulation);
$("exportBtn").addEventListener("click", exportJSON);
$("importBtn").addEventListener("click", () => $("fileInput").click());
$("fileInput").addEventListener("change", event => importJSON(event.target.files[0]));

$("deviceModal").addEventListener("click", event => {
    if (event.target === $("deviceModal")) closeModal();
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !$("deviceModal").classList.contains("hidden")) {
        closeModal();
    }
});

window.addEventListener("resize", updateChart);

renderAll();
