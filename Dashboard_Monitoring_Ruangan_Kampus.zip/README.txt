DASHBOARD MONITORING RUANGAN KAMPUS

Cara menjalankan:
1. Ekstrak folder project.
2. Buka file index.html menggunakan Google Chrome atau Microsoft Edge.
3. Dashboard langsung menampilkan 5 perangkat simulasi.
4. Gunakan Tambah Perangkat untuk menambah data.
5. Gunakan Edit/Hapus untuk mengelola perangkat.
6. Gunakan pencarian dan filter untuk mencari data.
7. Klik Mulai Simulasi untuk mengubah data otomatis.
8. Klik Ekspor JSON untuk membuat file JSON.
9. File JSON dapat dimasukkan kembali menggunakan Impor JSON.

Catatan:
Project tidak menggunakan library eksternal sehingga dapat dijalankan tanpa internet.
Grafik dibuat menggunakan Canvas API bawaan JavaScript.
